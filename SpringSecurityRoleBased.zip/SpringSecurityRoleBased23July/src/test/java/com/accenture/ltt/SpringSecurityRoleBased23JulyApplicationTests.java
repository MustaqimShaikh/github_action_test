package com.accenture.ltt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityRoleBased23JulyApplicationTests {

	@Test
	void contextLoads() {
	}

}
