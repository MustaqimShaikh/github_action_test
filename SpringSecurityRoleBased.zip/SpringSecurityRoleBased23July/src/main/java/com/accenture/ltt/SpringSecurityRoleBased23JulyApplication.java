package com.accenture.ltt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityRoleBased23JulyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityRoleBased23JulyApplication.class, args);
		System.out.println("Application is Running");
	}

}
