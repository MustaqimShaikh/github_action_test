package com.accenture.ltt.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SpringSecurityWebConfig {
	

@Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http.csrf().disable(); 
		
		http.authorizeRequests()			
		        .antMatchers("/user/**").access("hasAnyRole('USER','ADMIN')")
		        .antMatchers("/admin/**").access("hasRole('ADMIN')")
		        .antMatchers("/dba/**").access("hasRole('DBA')")
		        .and().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and().httpBasic();
		return http.build();
	}

	
	
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().passwordEncoder(new BCryptPasswordEncoder())
		.withUser("user").password(new BCryptPasswordEncoder().encode("user")).roles("USER")
		.and()
		.withUser("dba").password(new BCryptPasswordEncoder().encode("dba")).roles("DBA")
		.and()
		.withUser("admin").password(new BCryptPasswordEncoder().encode("admin")).roles("ADMIN");
		
	}



}
