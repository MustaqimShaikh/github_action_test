package com.accenture.ltt.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	
	@GetMapping(value = "/user")
	public String getUserDetail() {
		
		return "It is from user end point";
	}
	
	
	@GetMapping(value = "/admin")
	public String getAdminDetail() {
		
		return "It is from Admin end point";
	}
	
	
	@GetMapping(value = "/dba")
	public String getDBADetail() {
		
		return "It is from DBA end point";
	}

}
